<!DOCTYPE html>
<html>
<head>
    <title>User Accounts</title>
</head>
<body>
    <nav>
        <a href="<?php echo e(url('/')); ?>">Home</a> |
        <a href="<?php echo e(url('/about')); ?>">About</a> |
        <a href="<?php echo e(url('/customers')); ?>">Customers</a> |
        <a href="<?php echo e(url('/users')); ?>">Users</a>
    </nav>
    <h1>User Accounts</h1>
    <ul>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($user['username']); ?> - Role: <?php echo e($user['role']); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</body>
</html><?php /**PATH C:\Users\ncpablo\pos-laravel\resources\views/users.blade.php ENDPATH**/ ?>